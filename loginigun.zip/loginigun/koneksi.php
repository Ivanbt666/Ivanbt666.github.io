<?php
$koneksi = mysqli_connect("localhost","root","","loginivan666");

if (mysqli_connect_error()){
 echo "Koneksi database gagal : " . mysqli_connect_error();
}

?>