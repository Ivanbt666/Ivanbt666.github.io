
<html>
<head>
 <title>LOGIN MULTIUSER PHP</title>
 <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

 <div class="panel_login">
 <br>
  <center><img src="index.jpg" width="300 px" height="185 px"></center>
  <br>

  <form action="cekkoneksi.php" method="post">
   <input type="text" name="username" class="form_login" placeholder="Username" required="required">

   <input type="password" name="password" class="form_login" placeholder="Password" required="required">

   <input type="submit" class="tombol_login" value="LOGIN">

   <br/>
   <br/>
   
  </form>
  
 </div>


</body>
</html>